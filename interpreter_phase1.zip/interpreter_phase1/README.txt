Interpreter Phase 1
Team Members: 
*Julian Contreras
*Jonas Setzer

Contributions:
*Julian Contreras:
- Implemented For loop statements
- Implemented Print statements

*Jonas Setzer:
- Added relational operators to token and tokenizer
- Updated parser class with real expressions and real terms functions	

AI Use:
* No AI was used at any stage in development

Building and Running

Project must be built from the command line with:

make

This command produces an executable named interpreter.x. The interpreter must accept exactly one command-line argument: the name of the input file.

For example:

./interpreter.x tests/basic-loop.txt
