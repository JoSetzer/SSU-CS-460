Interpreter Phase 1
