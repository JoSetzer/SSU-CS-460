#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <sstream>
#include "Expr.hpp"

#include <limits>

ExprNode::ExprNode(Token token) : expressionToken{std::move(token)} {}

const Token &ExprNode::token() const {
    return expressionToken;
}

BinaryExprNode::BinaryExprNode(Token token, ExprNode *left, ExprNode *right)
    : ExprNode{std::move(token)},
      leftOperand{left},
      rightOperand{right} {}

BinaryExprNode::~BinaryExprNode() {
    delete leftOperand;
    delete rightOperand;
}

ValueDescriptor *BinaryExprNode::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor* leftValue = leftOperand->evaluate(symbolTable);
    ValueDescriptor* rightValue = nullptr;

    ValueDescriptor *result = nullptr;

    try {
        rightValue = rightOperand->evaluate(symbolTable);

        if (token().isAdditionOperator())
            result = additionOperation(leftValue, rightValue);
        if (token().isSubtractionOperator())
            result = subtractionOperation(leftValue, rightValue);
        if (token().isMultiplicationOperator())
            result = multiplicationOperation(leftValue, rightValue);
        if (token().isCompareOperator())
            result = equalsOperation(leftValue, rightValue);
        if (token().isNotEqualOperator())
            result = notEqualsOperation(leftValue, rightValue);
        if (token().isGreaterThanOperator())
            result = greaterOperation(leftValue, rightValue);
        if (token().isGreaterThanOrEqualOperator())
            result = greaterOrEqualsOperation(leftValue, rightValue);
        if (token().isLessThanOperator())
            result = lessOperation(leftValue, rightValue);
        if (token().isLessThanOrEqualOperator())
            result = lessOrEqualsOperation(leftValue, rightValue);
        if (token().isDivisionOperator())
            result = divisionOperation(leftValue, rightValue);
        if (token().isFloorDivisionOperator())
            result = floorDivisionOperation(leftValue, rightValue);
        if (token().isModuloOperator())
            result = moduloOperation(leftValue, rightValue);
    } catch (...) {
        delete leftValue;
        delete rightValue;
        throw;
    }

    delete leftValue;
    delete rightValue;
    return result;
}

ValueDescriptor *BinaryExprNode::additionOperation(ValueDescriptor *left, ValueDescriptor *right) const {

    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    ValueDescriptor::Type stringVal = ValueDescriptor::Type::string;

    // if both operances are integers
    if (left->type() == integer && right->type() == integer) {
            std::int64_t result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() +
                dynamic_cast<const IntegerValueDescriptor*>(right)->value();
            return new IntegerValueDescriptor(result);
        }
    // one or both operands is a double
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        double result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() + r;
        return new DoubleValueDescriptor(result);
    }
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        double result = l + dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }
    if (left->type() == doubleVal && right->type() == doubleVal) {
        double l = dynamic_cast<const DoubleValueDescriptor*>(left)->value();
        double r = dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        double result = l + r;
        return new DoubleValueDescriptor(result);
    }

    // One or both operands is a string
    if (left->type() == stringVal && right->type() == stringVal) {
        std::string l = dynamic_cast<const StringValueDescriptor*>(left)->value();
        std::string r = dynamic_cast<const StringValueDescriptor*>(right)->value();
        std::string result = l + r;
        return new StringValueDescriptor(result);
    }
    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::subtractionOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;

    // both operands are integers
    if (left->type() == integer && right->type() == integer) {
        std::int64_t result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() -
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new IntegerValueDescriptor(result);
    }
    // one or both operands are doubles
    // integer - double
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        double result = l - dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }
    // double - integer
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        double result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() - r;
        return new DoubleValueDescriptor(result);
    }
    // double - double
    if (left->type() == doubleVal && right->type() == doubleVal) {
        double result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() -
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::multiplicationOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;

    // integer * integer
    if (left->type() == integer && right->type() == integer) {
        std::int64_t result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() *
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new IntegerValueDescriptor(result);
    }
    // double * double
    if (left->type() == doubleVal && right->type() == doubleVal) {
        double result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() *
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }
    // integer * double
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        double result = l * dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }
    // double * integer
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        double result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() * r;
        return new DoubleValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::divisionOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;

    if (right->type() ==integer)
        if (static_cast<double>(dynamic_cast<const IntegerValueDescriptor*>(right)->value()) == 0.0)
            throw std::runtime_error("division by zero at line " + std::to_string(token().lineNumber()));

    if (right->type() == doubleVal)
        if (dynamic_cast<const DoubleValueDescriptor*>(right)->value() == 0.0)
            throw std::runtime_error("division by zero at line " + std::to_string(token().lineNumber()));

    // integer / integer
    if (left->type() == integer && right->type() == integer) {
        double result = static_cast<double>(dynamic_cast<const IntegerValueDescriptor*>(left)->value()) /
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }

    // double / double
    if (left->type() == doubleVal && right->type() == doubleVal) {
        double result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() /
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }

    //integer / double
    if (left->type() == integer && right->type() == doubleVal) {
        std::int64_t l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        double result = l / dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new DoubleValueDescriptor(result);
    }

    // double / integer
    if (left->type() == doubleVal && right->type() == integer) {
        std::int64_t r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        double result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() / r;
        return new DoubleValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::floorDivisionOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;

    if (right->type() == integer)
        if (dynamic_cast<const IntegerValueDescriptor*>(right)->value() == 0)
            throw std::runtime_error("division by zero at line " + std::to_string(token().lineNumber()));

    // integer // integer
    if (left->type() == integer && right->type() == integer) {
        std::int64_t l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        std::int64_t r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        std::int64_t result = l / r;
        std::int64_t remainder = l % r;
        if (remainder != 0 && ((remainder < 0) != (r < 0)))
            result -= 1;
        return new IntegerValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::equalsOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    ValueDescriptor::Type boolVal = ValueDescriptor::Type::boolean;
    ValueDescriptor::Type stringVal = ValueDescriptor::Type::string;
    ValueDescriptor::Type list = ValueDescriptor::Type::list;

    // operands are of the same type
    if (left->type() == right->type()) {
        if (left->type() == list)
	    return new BooleanValueDescriptor(
			    dynamic_cast<const ListValueDescriptor*>(left)->equals(
			    *dynamic_cast<const ListValueDescriptor*>(right)));
	if (left->type() == integer && right->type() == integer) {
            bool result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() == dynamic_cast<const IntegerValueDescriptor*>(right)->value();
            return new BooleanValueDescriptor(result);
        }
        if (left->type() == doubleVal && right->type() == doubleVal) {
            bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() == dynamic_cast<const DoubleValueDescriptor*>(right)->value();
            return new BooleanValueDescriptor(result);
        }
        if (left->type() == boolVal && right->type() == boolVal) {
            bool result = dynamic_cast<const BooleanValueDescriptor*>(left)->value() == dynamic_cast<const BooleanValueDescriptor*>(right)->value();
            return new BooleanValueDescriptor(result);
        }
        if (left->type() == stringVal && right->type() == stringVal) {
            bool result = dynamic_cast<const StringValueDescriptor*>(left)->value() == dynamic_cast<const StringValueDescriptor*>(right)->value();
            return new BooleanValueDescriptor(result);
        }
    }

    //operands are a integer and double
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        bool result = l == dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        bool result = r == dynamic_cast<const DoubleValueDescriptor*>(left)->value();
        return new BooleanValueDescriptor(result);
    }

    return new BooleanValueDescriptor(false);
}

ValueDescriptor *BinaryExprNode::notEqualsOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    ValueDescriptor::Type boolVal = ValueDescriptor::Type::boolean;
    ValueDescriptor::Type stringVal = ValueDescriptor::Type::string;
    ValueDescriptor::Type list = ValueDescriptor::Type::list;
    //lists
    if (left->type() == list && right->type() == list)
	return new BooleanValueDescriptor(
	    !dynamic_cast<const ListValueDescriptor*>(left)->equals(
	    *dynamic_cast<const ListValueDescriptor*>(right)));
    //integers
    if (left->type() == integer && right->type() == integer) {
        bool result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() !=
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // doubles
    if (left->type() == doubleVal && right->type() == doubleVal) {
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() !=
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // booleans
    if (left->type() == boolVal && right->type() == boolVal) {
        bool result = dynamic_cast<const BooleanValueDescriptor*>(left)->value() !=
            dynamic_cast<const BooleanValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // strings
    if (left->type() == stringVal && right->type() == stringVal) {
        bool result = dynamic_cast<const StringValueDescriptor*>(left)->value() !=
            dynamic_cast<const StringValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // doubles and integers
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        bool result = l != dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        bool result = r != dynamic_cast<const DoubleValueDescriptor*>(left)->value();
        return new BooleanValueDescriptor(result);
    }

    return new BooleanValueDescriptor(true);
}

ValueDescriptor *BinaryExprNode::moduloOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;

    if (right->type() == integer) {
        if (dynamic_cast<const IntegerValueDescriptor*>(right)->value() == 0) {
            throw std::runtime_error("division by zero at line " + std::to_string(token().lineNumber()));
        }
    }

    // integer % integer
    if (left->type() == integer && right->type() == integer) {
        std::int64_t l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        std::int64_t r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        std::int64_t result = l % r;
        if (result != 0 && ((result < 0) != (r < 0)))
            result += r;
        return new IntegerValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::lessOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    ValueDescriptor::Type stringVal = ValueDescriptor::Type::string;

    // integer < integer
    if (left->type() == integer && right->type() == integer) {
        bool result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() <
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double < double
    if (left->type() == doubleVal && right->type() == doubleVal) {
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() <
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // integer < double
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        bool result = l < dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double < integer
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() < r;
        return new BooleanValueDescriptor(result);
    }

    // string < string
    if (left->type() == stringVal && right->type() == stringVal) {
        bool result = dynamic_cast<const StringValueDescriptor*>(left)->value() <
            dynamic_cast<const StringValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::lessOrEqualsOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    ValueDescriptor::Type stringVal = ValueDescriptor::Type::string;

    // integer < integer
    if (left->type() == integer && right->type() == integer) {
        bool result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() <=
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double < double
    if (left->type() == doubleVal && right->type() == doubleVal) {
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() <=
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // integer < double
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        bool result = l <= dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double < integer
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() <= r;
        return new BooleanValueDescriptor(result);
    }

    // string < string
    if (left->type() == stringVal && right->type() == stringVal) {
        bool result = dynamic_cast<const StringValueDescriptor*>(left)->value() <=
            dynamic_cast<const StringValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::greaterOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    ValueDescriptor::Type stringVal = ValueDescriptor::Type::string;

    // integer > integer
    if (left->type() == integer && right->type() == integer) {
        bool result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() >
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double > double
    if (left->type() == doubleVal && right->type() == doubleVal) {
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() >
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // integer > double
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        bool result = l > dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double > integer
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() > r;
        return new BooleanValueDescriptor(result);
    }

    // string > string
    if (left->type() == stringVal && right->type() == stringVal) {
        bool result = dynamic_cast<const StringValueDescriptor*>(left)->value() >
            dynamic_cast<const StringValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }

    typeError(left, right);
}

ValueDescriptor *BinaryExprNode::greaterOrEqualsOperation(ValueDescriptor *left, ValueDescriptor *right) const {
    // simplify type comparisons
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    ValueDescriptor::Type stringVal = ValueDescriptor::Type::string;

    // integer >= integer
    if (left->type() == integer && right->type() == integer) {
        bool result = dynamic_cast<const IntegerValueDescriptor*>(left)->value() >=
            dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double >= double
    if (left->type() == doubleVal && right->type() == doubleVal) {
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() >=
            dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // integer >= double
    if (left->type() == integer && right->type() == doubleVal) {
        double l = dynamic_cast<const IntegerValueDescriptor*>(left)->value();
        bool result = l >= dynamic_cast<const DoubleValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }
    // double >= integer
    if (left->type() == doubleVal && right->type() == integer) {
        double r = dynamic_cast<const IntegerValueDescriptor*>(right)->value();
        bool result = dynamic_cast<const DoubleValueDescriptor*>(left)->value() >= r;
        return new BooleanValueDescriptor(result);
    }

    // string >= string
    if (left->type() == stringVal && right->type() == stringVal) {
        bool result = dynamic_cast<const StringValueDescriptor*>(left)->value() >=
            dynamic_cast<const StringValueDescriptor*>(right)->value();
        return new BooleanValueDescriptor(result);
    }

    typeError(left, right);
}

void BinaryExprNode::typeError(const ValueDescriptor *left, const ValueDescriptor *right) const {
    const char *s = token().symbol();
    std::string op(s, s[1] == '\0' ? 1 : 2);

    std::string message =
    "type error at line " + std::to_string(token().lineNumber()) +
    ": unsupported operand types for '" + op + "': " +
    left->typeName() + " and " + right->typeName();

    throw std::runtime_error(message);
}


void BinaryExprNode::print() const {
    std::cout << '(';
    leftOperand->print();
    token().print(std::cout);
    rightOperand->print();
    std::cout << ')';
}

UnaryExprNode::UnaryExprNode(Token token, ExprNode *operand)
    : ExprNode{std::move(token)}, expression{operand} {}

UnaryExprNode::~UnaryExprNode() {
    delete expression;
}

ValueDescriptor *UnaryExprNode::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor::Type integer = ValueDescriptor::Type::integer;
    ValueDescriptor::Type doubleVal = ValueDescriptor::Type::doubleValue;
    
    const ValueDescriptor *value = expression->evaluate(symbolTable);
    
    if (token().isAdditionOperator()) {
	if (value->type() == integer) {
		std::int64_t result = dynamic_cast<const IntegerValueDescriptor*>(value)->value();
		delete value;
		return new IntegerValueDescriptor(result);
	}
	if (value->type() == doubleVal) {
		double result = dynamic_cast<const DoubleValueDescriptor*>(value)->value();
		delete value;
		return new DoubleValueDescriptor(result);
	}
    }
    
    if (token().isSubtractionOperator()) {
	if (value->type() == integer) {
		std::int64_t result = dynamic_cast<const IntegerValueDescriptor*>(value)->value();
		delete value;
    		return new IntegerValueDescriptor(-result);
	}
	if (value->type() == doubleVal) {
		double result = dynamic_cast<const DoubleValueDescriptor*>(value)->value();
		delete value;
		return new DoubleValueDescriptor(-result);
	}
    }
    
    delete value;
    throw std::logic_error("unsupported prefix operator");
}

void UnaryExprNode::print() const {
    std::cout << token().symbol();
    expression->print();
}

IntegerLiteral::IntegerLiteral(Token token) : ExprNode{std::move(token)} {}

void IntegerLiteral::print() const {
    token().print(std::cout);
}

ValueDescriptor *IntegerLiteral::evaluate(const SymbolTable &) const {
    return new IntegerValueDescriptor(token().integerValue());
}

DoubleLiteral::DoubleLiteral(Token token) : ExprNode{std::move(token)} {}

void DoubleLiteral::print() const {
    token().print(std::cout);
}

ValueDescriptor *DoubleLiteral::evaluate(const SymbolTable &) const {
    return new DoubleValueDescriptor(token().doubleValue());
}

StringLiteral::StringLiteral(Token token) : ExprNode{std::move(token)} {}

void StringLiteral::print() const {
    token().print(std::cout);
}

ValueDescriptor *StringLiteral::evaluate(const SymbolTable &) const {
    return new StringValueDescriptor(token().stringValue());
}

BoolLiteral::BoolLiteral(Token token) : ExprNode{std::move(token)} {}

void BoolLiteral::print() const {
    token().print(std::cout);
}

ValueDescriptor *BoolLiteral::evaluate(const SymbolTable &) const {
    return new BooleanValueDescriptor(token().booleanValue());
}

ListLiteral::ListLiteral(Token token) : ExprNode{std::move(token)} {}

ListLiteral::~ListLiteral() {
	for (ExprNode* expr : expressions)
		delete expr;
}

void ListLiteral::addExpr(ExprNode* expression) {
	expressions.push_back(expression);
}

void ListLiteral::print() const {
	std:: cout << "[";

	for (std::size_t i = 0; i < expressions.size(); i++) {
		if (i > 0)
			std::cout << ", ";
		expressions[i]->print();
	}
	std::cout << "]";
}

ValueDescriptor *ListLiteral::evaluate(const SymbolTable &symbolTable) const {
	ListValueDescriptor* list = new ListValueDescriptor();

	try {
		for (ExprNode* exprIndex : expressions) {
			ValueDescriptor* value = exprIndex->evaluate(symbolTable);

			try {
				list->append(value);
			} catch (...) {
				delete value;
				throw;
			}
		}
	}
	catch (...) {
		delete list;
		throw;
	}
	return list;
}

StringConversion::StringConversion(Token token, ExprNode *operand): ExprNode{std::move(token)}, literal(operand) {}

StringConversion::~StringConversion() {
    delete literal;
}

ValueDescriptor *StringConversion::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor* str = literal->evaluate(symbolTable);

    std::string result = str->toString();

    delete str;

    return new StringValueDescriptor(std::move(result));
}

void StringConversion::print() const {
    std::cout << "str(";
    literal->print();
    std::cout << ')';
}

IntegerConversion::IntegerConversion(Token token, ExprNode *operand): ExprNode{std::move(token)}, literal(operand) {}

IntegerConversion::~IntegerConversion() {
    delete literal;
}

ValueDescriptor *IntegerConversion::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor* integer = literal->evaluate(symbolTable);

    if (integer->type() == ValueDescriptor::Type::integer) {
        return integer;
    }

    if (integer->type() != ValueDescriptor::Type::string) {
        std::string typeName = integer->typeName();
        delete integer;
        throw std::runtime_error("int() cannot convert a " + typeName + " at line " + std::to_string(token().lineNumber()));
    }

    std::string operand = dynamic_cast<const StringValueDescriptor *>(integer)->value();
    delete integer;

    int place = 0;
    int size = operand.size();
    std::int64_t value = 0;
    char sign;

    if (operand[place] == '+' || operand[place] == '-') {
        sign = operand[place];
        place++;
    }
    else {
        sign = ' ';
    }

    if (place == size) {
        throw std::runtime_error("Error in IntegerConversion::evaluate(): Invalid operand size at line " + std::to_string(token().lineNumber()));
    }

    for (; place < size; place++) {

        if (operand[place] < '0' || operand[place] > '9') {
            std::string message = "Error in IntegerConversion::evaluate(): does not accept " + operand + " at line " + std::to_string(token().lineNumber());
            throw std::runtime_error(message);
        }

        std::int64_t digit = operand[place] - '0';

        if (value > (std::numeric_limits<std::int64_t>::max() - digit) / 10) {
            std::string message = "Error in IntegerConversion::evaluate(): value is too large at line " + std::to_string(token().lineNumber());
            throw std::runtime_error(message);
        }

        value = value * 10 + digit;
    }

    if (sign == '-') {
        value = value * -1;
    }

    return new IntegerValueDescriptor(value);
}

void IntegerConversion::print() const {
    std::cout << "int(";
    literal->print();
    std::cout << ')';
}

FloatConversion::FloatConversion(Token token, ExprNode *operand) : ExprNode {std::move(token)}, literal(operand) {}

FloatConversion::~FloatConversion() {
    delete literal;
}

ValueDescriptor *FloatConversion::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor* floatpoint = literal->evaluate(symbolTable);

    // if it's already a float
    if (floatpoint->type() == ValueDescriptor::Type::doubleValue) {
        return floatpoint;
    }

    // it's an integer
    if (floatpoint->type() == ValueDescriptor::Type::integer) {
        auto value = static_cast<double>(dynamic_cast<const IntegerValueDescriptor *>(floatpoint)->value());
        delete floatpoint;

        return new DoubleValueDescriptor(value);
    }

    // if it is not a string then throw an error
    if (floatpoint->type() != ValueDescriptor::Type::string) {
        std::string typeName = floatpoint->typeName();
        delete floatpoint;
        throw std::runtime_error("float() cannot convert a " + typeName + " at line " + std::to_string(token().lineNumber()));
    }

    // get the string
    std::string operand = dynamic_cast<const StringValueDescriptor *>(floatpoint)->value();
    delete floatpoint;

    //setup
    int place = 0;
    int size = operand.size();
    int decimalCount = 0;
    int invalidCharCount = 0;
    bool beforeDecimal = false;
    bool afterDecimal = false;

    // check for a sign
    if (operand[place] == '+' || operand[place] == '-') {
        place++;
    }

    // if it only has a sign then throw
    if (place == size) {
        throw std::runtime_error("Error in FloatConversion::evaluate(): Invalid operand size at line " + std::to_string(token().lineNumber()));
    }

    if (operand[place] >= '0' && operand[place] <= '9') {
        beforeDecimal = true;
    }

    while (place < size) {
        if (operand[place] == '.') {
            decimalCount++;
            place++;

            if (place != size) {
                afterDecimal = true;
            }
            continue;
        }

        if (operand[place] < '0' || operand[place] > '9') {
            invalidCharCount++;
        }
        place++;
    }

    if (decimalCount > 1) {
        throw std::runtime_error("Error in FloatConversion::evaluate(): Invalid operand " + operand + " at line " + std::to_string(token().lineNumber()));
    }

    if (invalidCharCount > 0) {
        std::string message = "Error in FloatConversion::evaluate(): does not accept " + operand + " at line " + std::to_string(token().lineNumber());
        throw std::runtime_error(message);
    }

    if (!beforeDecimal || (decimalCount == 1 && !afterDecimal)) {
        std::string message = "Error in FloatConversion::evaluate(): does not accept " + operand + " at line " + std::to_string(token().lineNumber());
        throw std::runtime_error(message);
    }

    double value = std::stod(operand);

    return new DoubleValueDescriptor(value);
}

void FloatConversion::print() const {
    std::cout << "float(";
    literal->print();
    std::cout << ')';
}

LenExpr::LenExpr(Token token, ExprNode *expression) : ExprNode(std::move(token)), expression(expression) {}

LenExpr::~LenExpr() {
    delete expression;
}

ValueDescriptor *LenExpr::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor* object = expression->evaluate(symbolTable);
    std::size_t len;
    // if it's a string
    if (object->type() == ValueDescriptor::Type::string) {
	len = dynamic_cast<StringValueDescriptor*>(object)->value().size();
        delete object;
        return new IntegerValueDescriptor(static_cast<std::int64_t>(len));
    }
    // if it's a list
    if (object->type() == ValueDescriptor::Type::list) {
    	ListValueDescriptor* list = dynamic_cast<ListValueDescriptor*>(object);
	len = list->size();
	delete object;
	return new IntegerValueDescriptor(static_cast<std::int64_t>(len));
    }
    

    // if anything not a string or list
    std::string message = "Error in LenExpr::evaluate(): invalid type" + object->typeName() + " at line " + std::to_string(token().lineNumber());
    delete object;
    throw std::runtime_error(message);
}

void LenExpr::print() const {
    std::cout << "len(";
    expression->print();
    std::cout << ')';
}

SplitExpr::SplitExpr(Token token, ExprNode *expression) : ExprNode(std::move(token)), expression(expression) {}

SplitExpr::~SplitExpr() {
    delete expression;
}

void SplitExpr::print() const {
    std::cout << "split(";
    expression->print();
    std::cout << ")";
}

ValueDescriptor *SplitExpr::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor* object = expression->evaluate(symbolTable);

    if (object->type() != ValueDescriptor::Type::string) {
	std::string message = object->typeName();
	delete object;
        throw std::runtime_error("split() rquires string, got: " + message);
    }
    
    std::string original = dynamic_cast<StringValueDescriptor*>(object)->value();
    delete object;

    ListValueDescriptor* list = new ListValueDescriptor();

    std::istringstream stream(original);
    std::string word;
    
    try{
    	while (stream >> word) {
	    ValueDescriptor* value = new StringValueDescriptor(word);
	    try {
	    	list->append(value);
	    } catch (...) {
		delete value;
		throw;
	    }
	}
    } catch (...) {
	delete list;
	throw;
    }
    return list;
}

Variable::Variable(Token token) : ExprNode{std::move(token)} {}

void Variable::print() const {
    token().print(std::cout);
}

ValueDescriptor *Variable::evaluate(const SymbolTable &symbolTable) const {

    if (!symbolTable.isDefined(token().identifier()))
        throw std::runtime_error("Unknown variable: " + token().identifier());

    return symbolTable.getValueFor(token().identifier())->clone();
}

EvaluatedRange::EvaluatedRange(ValueDescriptor *start, ValueDescriptor *stop, ValueDescriptor *step):
				start_(start), stop_(stop), step_(step) {
    	if(dynamic_cast<IntegerValueDescriptor*>(step_)->value() == 0) {
		delete start_;
		delete stop_;
		delete step_;
		throw std::logic_error("error: zero-value step");
	}
}

ValueDescriptor *EvaluatedRange::start() const {return start_;}

ValueDescriptor *EvaluatedRange::stop() const {return stop_;}

ValueDescriptor *EvaluatedRange::step() const {return step_;}

EvaluatedRange::~EvaluatedRange () {
	delete start_;
	delete stop_;
	delete step_;
}

bool EvaluatedRange::hasIteration() const {
	std::int64_t start, stop, step;
	start = dynamic_cast<IntegerValueDescriptor*>(start_)->value();
	stop = dynamic_cast<IntegerValueDescriptor*>(stop_)->value();
	step = dynamic_cast<IntegerValueDescriptor*>(step_)->value();
	
	if (step > 0)
		return start < stop;
	return start > stop;
}

bool EvaluatedRange::shouldContinue (ValueDescriptor *nextValue_) const {
	std::int64_t step, stop, nextValue;
	step = dynamic_cast<IntegerValueDescriptor*>(step_)->value();
	stop = dynamic_cast<IntegerValueDescriptor*>(stop_)->value();
	nextValue = dynamic_cast<IntegerValueDescriptor*>(nextValue_)->value();
	delete nextValue_;

	if (step > 0)
		return nextValue < stop;
	return nextValue > stop;
}

RangeExpression::RangeExpression(ExprNode *stop):
	startExpression(NULL),
	stopExpression(stop),
	stepExpression(NULL)
	{}
RangeExpression::RangeExpression(ExprNode *start, ExprNode *stop):
	startExpression(start),
	stopExpression(stop),
	stepExpression(NULL)
	{}
RangeExpression::RangeExpression(
	ExprNode *start,
	ExprNode *stop,
	ExprNode *step
	): 
	startExpression(start),
	stopExpression(stop),
	stepExpression(step)
	{}

RangeExpression::~RangeExpression(){
	delete startExpression;
	delete stopExpression;
	delete stepExpression;
}

EvaluatedRange RangeExpression::evaluate(const SymbolTable& symbolTable) const {
	ValueDescriptor *start = nullptr, *stop = nullptr, *step = nullptr;
    	ValueDescriptor::Type integer = ValueDescriptor::Type::integer;

    try {
        if (startExpression != nullptr) {
            start = startExpression->evaluate(symbolTable);
            if (start->type() != integer) {
                throw std::runtime_error("RangeExpression::evaluate non-integer range value");
            }
        } else
            start = new IntegerValueDescriptor(0);

        if (stepExpression != nullptr) {
            step = stepExpression->evaluate(symbolTable);
            if (step->type() != integer) {
                throw std::runtime_error("RangeExpression::evaluate non-integer range value");
            }
        } else
            step = new IntegerValueDescriptor(1);

        stop = stopExpression->evaluate(symbolTable);
        if (stop->type() != integer) {
            throw std::runtime_error("RangeExpression::evaluate non-integer range value");
        }
    } catch (...) {
        delete start;
        delete stop;
        delete step;
        throw;
    }

	return EvaluatedRange(start, stop, step);
}

void RangeExpression::print(std::ostream& output) const {
    output << "range(";

    if (startExpression == nullptr) {
        stopExpression->print();
    }
    else if (stepExpression == nullptr) {
        startExpression->print();
        output << ", ";
        stopExpression->print();
    }
    else {
        startExpression->print();
        output << ", ";
        stopExpression->print();
        output << ", ";
        stepExpression->print();
    }
    output << ")";
}

SubscriptExpr::SubscriptExpr(Token token, ExprNode *object, ExprNode *subscript) : ExprNode{std::move(token)}, object{object}, subscript{subscript} {}

SubscriptExpr::~SubscriptExpr() {
    delete object;
    delete subscript;
}

void SubscriptExpr::print() const {
	object->print();
	std::cout << "[";
	subscript->print();
	std::cout << "]";
}

ValueDescriptor *SubscriptExpr::evaluate(const SymbolTable &symbolTable) const {
    ValueDescriptor *obj = object->evaluate(symbolTable);
    ValueDescriptor *subscr = nullptr;

    try {
        subscr = subscript->evaluate(symbolTable);
    } catch (...) {
        delete obj;
        throw;
    }

    if (subscr->type() != ValueDescriptor::Type::integer) {
        delete obj;
        delete subscr;

        throw std::runtime_error("Error at SubscriptExpr::evaluate(): subscript type mismatch");
    }
    std::int64_t i = dynamic_cast<IntegerValueDescriptor*>(subscr)->value();
    delete subscr;

    if (obj->type() == ValueDescriptor::Type::list) {
    	if (i < 0) {
            delete obj;
            throw std::runtime_error("Error at SubscriptExpr::evaluate(): subscript out of range");	
	}
	ListValueDescriptor* list = dynamic_cast<ListValueDescriptor*>(obj);
	ValueDescriptor* result = nullptr;
	try{
		result = list->getElement(static_cast<std::size_t>(i));
	}
	catch(...) {
		delete obj;
		throw;
	}
	delete obj;
	return result;
    }
    if (obj->type() == ValueDescriptor::Type::string) {
        const std::string &s = dynamic_cast<StringValueDescriptor*>(obj)->value();

        if (i < 0 || i >= s.size()) {
            delete obj;
            throw std::runtime_error("Error at SubscriptExpr::evaluate(): subscript out of range");
        }

        std::string character = std::string(1, s.at(i));
        delete obj;
        return new StringValueDescriptor(character);
    }

    // if it's not a string or a list
    delete obj;

    throw std::runtime_error("Error at SubscriptExpr::evaluate(): subscript type mismatch");
}

PopExpr::PopExpr(Token token, ExprNode* expression) : 
    ExprNode(std::move(token)), expression(expression) {}

PopExpr::~PopExpr() {
    delete expression;
}

void PopExpr::print() const{
    std::cout << "pop(";
    expression->print();
    std::cout << ")";
}

ValueDescriptor* PopExpr::evaluate(const SymbolTable& symbolTable) const{
	ValueDescriptor* object = expression->evaluate(symbolTable);

	if (object->type() != ValueDescriptor::Type::list){
	    std::string type = object->typeName();
	    delete object;
	    throw std::runtime_error("pop() requires list, got: " + type);
	}

	ListValueDescriptor* list = dynamic_cast<ListValueDescriptor*>(object);
	ValueDescriptor* result;

	try{
	    result = list->pop();
	} catch (...) {
	    delete object;
	    throw;
	}
	delete object;
	return result;
}

InputExpr::InputExpr(Token token) : ExprNode(std::move(token)){}

void InputExpr::print() const{
    std::cout << "input()";
}

ValueDescriptor* InputExpr::evaluate(const SymbolTable& symbolTable) const {
    std::string input;
    if (!std::getline(std::cin, input))
	    throw std::runtime_error("input() failed to real line");

    return new StringValueDescriptor(input);
}
