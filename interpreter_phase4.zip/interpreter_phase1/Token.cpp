#include <iostream>

#include "Token.hpp"

void Token::print(std::ostream &output) const {
    if (isNewline())
        output << "NEWLINE";
    else if (isEof())
        output << "EOF";
    else if (isForKeyword())
        output << "for";
    else if (isWhileKeyword())
        output << "while";
    else if (isIfKeyword())
        output << "if";
    else if (isElifKeyword())
        output << "elif";
    else if (isElseKeyword())
        output << "else";
    else if (isPrintKeyword())
        output << "print";
    else if (isRangeKeyword())
	output << "range";
    else if (isStrKeyword())
	output << "str";
    else if (isIntKeyword())
        output << "int";
    else if (isFloatKeyword())
        output << "float";
    else if (isInKeyword())
	output << "in";
    else if (isLenKeyword())
        output << "len";
    else if (isSplitKeyword())
        output << "split";
    else if (isAppendKeyword())
        output << "append";
    else if (isPopKeyword())
        output << "pop";
    else if (isInputKeyword())
        output << "input";
    else if (isOpenParen())
        output << '(';
    else if (isCloseParen())
        output << ')';
    else if (isOpenBrace())
        output << '{';
    else if (isCloseBrace())
        output << '}';
    else if (isOpenBracket())
        output << '[';
    else if (isCloseBracket())
        output << ']';
    else if (isAssignmentOperator())
        output << " = ";
    else if (isCompareOperator())
	output << " == ";
    else if (isSemicolon())
        output << ';';
    else if (isMultiplicationOperator())
        output << " * ";
    else if (isAdditionOperator())
        output << " + ";
    else if (isSubtractionOperator())
        output << " - ";
    else if (isModuloOperator())
        output << " % ";
    else if (isDivisionOperator())
        output << " / ";
    else if (isFloorDivisionOperator())
        output << " // ";
    else if (isGreaterThanOperator())
        output << " > ";
    else if (isGreaterThanOrEqualOperator())
        output << " >= ";
    else if (isLessThanOperator())
        output << " < ";
    else if (isLessThanOrEqualOperator())
        output << " <= ";
    else if (isNotEqualOperator())
        output << " != ";
    else if (isIdentifier())
        output << identifier();
    else if (isInteger())
        output << integerValue();
    else if (isDouble())
        output << doubleValue();
    else if (isBoolean()) {
	if (booleanValue())
       		output << "True";
	else
		output << "False";
    } else if (isString())
        output << stringValue();
    else if (isIndent())
        output << "INDENT";
    else if (isDedent())
        output << "DEDENT";
    else if (isColon()) {
        output << ":";
    }
    else if (isComma()) {
        output << ",";
    }
    else
        output << "uninitialized token";
}
